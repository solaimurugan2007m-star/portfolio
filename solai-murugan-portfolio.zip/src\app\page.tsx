"use client";

import React from "react";
import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { About } from "@/components/About";
import { Skills } from "@/components/Skills";
import { Projects } from "@/components/Projects";
import { Cybersecurity } from "@/components/Cybersecurity";
import { LearningJourney } from "@/components/LearningJourney";
import { Contact } from "@/components/Contact";
import { Footer } from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-[#101010] text-[#ededed] flex flex-col font-sans selection:bg-[#cef042] selection:text-[#101010]">
      {/* Sticky Navigation */}
      <Navbar />

      {/* Main Content Sections */}
      <main className="flex-1">
        <Hero />
        <About />
        <Skills />
        <Projects />
        <Cybersecurity />
        <LearningJourney />
        <Contact />
      </main>

      {/* Minimalist Technical Footer */}
      <Footer />
    </div>
  );
}
