"use client";

import React, { useState, useEffect } from "react";
import { portfolioData } from "@/data/portfolio-data";
import { Menu, X } from "lucide-react";

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { identity } = portfolioData;

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { label: "About", href: "#about" },
    { label: "Skills", href: "#skills" },
    { label: "Projects", href: "#projects" },
    { label: "Security", href: "#security" },
    { label: "Education", href: "#journey" },
    { label: "Contact", href: "#contact" },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-200 ${
        scrolled
          ? "bg-[#101010]/90 backdrop-blur-md border-b border-[#242424] py-3.5 shadow-sm"
          : "bg-transparent py-5 border-b border-transparent"
      }`}
    >
      <div className="max-w-5xl mx-auto px-5 sm:px-8 flex items-center justify-between">
        {/* Monogram / Brand */}
        <a
          href="#home"
          className="group flex items-center gap-3 text-inherit no-underline focus:outline-none focus-visible:ring-1 focus-visible:ring-[#cef042]"
        >
          <div className="w-9 h-9 rounded-sm bg-[#181818] border border-[#2b2b2b] flex items-center justify-center font-mono text-xs font-bold tracking-wider text-[#cef042] group-hover:border-[#cef042] transition-colors">
            sm
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-semibold tracking-tight text-[#ededed] group-hover:text-white transition-colors">
              {identity.fullName}
            </span>
            <span className="text-[11px] font-mono text-[#71717a] hidden sm:inline">
              CS Engineering Student
            </span>
          </div>
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-7">
          <ul className="flex items-center gap-6 text-xs font-mono tracking-wide text-[#a1a1aa] list-none p-0 m-0">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="transition-colors hover:text-[#cef042] focus:outline-none focus-visible:text-[#cef042]"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>

          <div className="h-4 w-[1px] bg-[#282828]" />

          <a
            href="#contact"
            className="inline-flex items-center px-3.5 py-1.5 rounded-sm bg-[#cef042] hover:bg-[#d9f852] text-[#101010] text-xs font-mono font-semibold transition-colors"
          >
            Contact
          </a>
        </nav>

        {/* Mobile Menu Button */}
        <div className="flex items-center md:hidden">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-sm bg-[#161616] border border-[#2b2b2b] text-[#a1a1aa] hover:text-[#ededed] focus:outline-none focus-visible:ring-1 focus-visible:ring-[#cef042]"
            aria-label="Toggle Navigation Menu"
            aria-expanded={mobileMenuOpen}
          >
            {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#101010] border-b border-[#242424] px-5 py-6">
          <nav className="flex flex-col gap-4">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="text-sm font-mono text-[#a1a1aa] hover:text-[#cef042] py-1 border-b border-[#1c1c1c] transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
