import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Solai Murugan M — Software Developer | Security Learner | AI Builder",
  description:
    "Personal portfolio of Solai Murugan M, a third-year Computer Science Engineering student focused on full-stack development, practical cybersecurity, and AI-powered applications.",
  authors: [{ name: "Solai Murugan M" }],
  keywords: [
    "Solai Murugan M",
    "Computer Science Student",
    "Software Developer",
    "Full-Stack Development",
    "Web Application Security",
    "Cybersecurity Learner",
    "AI Builder",
    "Portfolio",
  ],
  openGraph: {
    title: "Solai Murugan M — Software Developer | Security Learner | AI Builder",
    description:
      "Computer Science student focused on full-stack development, practical cybersecurity, and AI-powered applications.",
    type: "website",
    locale: "en_US",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export const viewport: Viewport = {
  themeColor: "#101010",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <body className="min-h-screen bg-[#101010] text-[#ededed] antialiased selection:bg-[#cef042] selection:text-[#101010]">
        {children}
      </body>
    </html>
  );
}
