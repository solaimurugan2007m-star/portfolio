"use client";

import React, { useState } from "react";
import { portfolioData, SkillLevel } from "@/data/portfolio-data";

export function Skills() {
  const { skills } = portfolioData;
  const [activeFilter, setActiveFilter] = useState<string>("all");

  const getLevelBadge = (level: SkillLevel) => {
    switch (level) {
      case "Practiced":
        return "bg-[#cef042]/10 text-[#cef042] border-[#cef042]/30";
      case "Familiar":
        return "bg-[#ededed]/10 text-[#ededed] border-[#ededed]/20";
      case "Learning":
        return "bg-[#f59e0b]/10 text-[#f59e0b] border-[#f59e0b]/30";
      default:
        return "bg-[#1f1f1f] text-[#a1a1aa] border-[#2d2d2d]";
    }
  };

  return (
    <section id="skills" className="py-20 border-b border-[#202020] relative">
      <div className="max-w-5xl mx-auto px-5 sm:px-8">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
          <div>
            <span className="font-mono text-xs text-[#cef042] tracking-wider uppercase block mb-1">
              02 // Skills
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#ededed]">
              Technical Skills
            </h2>
          </div>

          {/* Simple Legend */}
          <div className="flex items-center gap-3 font-mono text-xs text-[#71717a]">
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#cef042]" /> Practiced
            </span>
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#ededed]" /> Familiar
            </span>
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#f59e0b]" /> Learning
            </span>
          </div>
        </div>

        {/* Skills Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {skills.map((category) => (
            <div
              key={category.title}
              className="bg-[#141414] border border-[#222222] rounded-sm p-5 space-y-4"
            >
              <h3 className="font-mono text-xs font-semibold text-[#ededed] uppercase tracking-wider pb-2 border-b border-[#202020]">
                {category.title}
              </h3>

              <div className="flex flex-wrap gap-2">
                {category.skills.map((skill) => (
                  <span
                    key={skill.name}
                    className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xs border text-xs font-mono ${getLevelBadge(
                      skill.level
                    )}`}
                  >
                    <span>{skill.name}</span>
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
