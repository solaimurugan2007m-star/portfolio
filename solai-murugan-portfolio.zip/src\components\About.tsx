import React from "react";
import { portfolioData } from "@/data/portfolio-data";
import { Code2, Shield, Sparkles, GraduationCap, Award, MapPin } from "lucide-react";

export function About() {
  const { identity } = portfolioData;

  const focusCards = [
    {
      icon: Code2,
      title: "Full-Stack Development",
      description:
        "Building practical web applications with React, Next.js, and Node.js. Focused on clean code, good UX, and solid database design.",
    },
    {
      icon: Shield,
      title: "Security Foundations",
      description:
        "Starting out with cybersecurity. Learning Linux systems, network protocols, and common web security concepts in authorized labs.",
    },
    {
      icon: Sparkles,
      title: "AI Experimentation",
      description:
        "Exploring modern AI tools and integrating LLM APIs into web apps to solve everyday problems.",
    },
  ];

  return (
    <section id="about" className="py-20 border-b border-[#202020] relative">
      <div className="max-w-5xl mx-auto px-5 sm:px-8">
        {/* Section Header */}
        <div className="mb-10">
          <span className="font-mono text-xs text-[#cef042] tracking-wider uppercase block mb-1">
            01 // About Me
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#ededed]">
            Background &amp; Education
          </h2>
        </div>

        {/* Narrative */}
        <div className="max-w-3xl space-y-4 text-base sm:text-lg text-[#a1a1aa] leading-relaxed mb-10">
          {identity.bio.map((paragraph, index) => (
            <p key={index}>{paragraph}</p>
          ))}
        </div>

        {/* Education Highlight Strip */}
        <div className="p-4 sm:p-5 rounded-sm bg-[#141414] border border-[#242424] flex flex-wrap items-center justify-between gap-4 mb-10 font-mono text-xs">
          <div className="flex items-center gap-2.5 text-[#ededed]">
            <GraduationCap className="w-4 h-4 text-[#cef042]" />
            <span>{identity.collegeName}</span>
          </div>
          <div className="flex items-center gap-4 text-[#a1a1aa]">
            <span className="flex items-center gap-1.5 text-[#cef042] font-semibold">
              <Award className="w-3.5 h-3.5" />
              CGPA: {identity.cgpa}
            </span>
            <span>•</span>
            <span className="flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#71717a]" />
              {identity.location}
            </span>
          </div>
        </div>

        {/* 3 Simple Focus Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {focusCards.map((card) => {
            const Icon = card.icon;
            return (
              <div
                key={card.title}
                className="p-5 rounded-sm bg-[#141414] border border-[#222222] hover:border-[#303030] transition-colors"
              >
                <div className="w-8 h-8 rounded-sm bg-[#1a1a1a] border border-[#282828] flex items-center justify-center text-[#cef042] mb-3">
                  <Icon className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-semibold text-[#ededed] mb-1.5">
                  {card.title}
                </h3>
                <p className="text-xs text-[#71717a] leading-relaxed">
                  {card.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
