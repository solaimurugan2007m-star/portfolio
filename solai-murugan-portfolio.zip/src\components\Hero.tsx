"use client";

import React from "react";
import { portfolioData } from "@/data/portfolio-data";
import { ArrowDown, ArrowUpRight, Code, Shield, MapPin, GraduationCap, Award } from "lucide-react";
import { GithubIcon, LinkedinIcon } from "@/components/BrandIcons";

export function Hero() {
  const { identity, contact } = portfolioData;

  return (
    <section id="home" className="pt-32 pb-20 md:pt-38 md:pb-24 border-b border-[#202020] relative">
      <div className="max-w-5xl mx-auto px-5 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          {/* Left Column: Headline & Bio */}
          <div className="lg:col-span-7 flex flex-col items-start">
            {/* Availability Badge */}
            {identity.isOpenToOpportunities && (
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#181818] border border-[#2a2a2a] text-xs font-mono text-[#a1a1aa] mb-6">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#cef042] opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-[#cef042]" />
                </span>
                <span>{identity.availabilityText}</span>
              </div>
            )}

            {/* Name & Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#ededed] leading-[1.1] mb-5">
              {identity.fullName}
              <span className="block text-xl sm:text-2xl lg:text-3xl font-normal text-[#a1a1aa] mt-2">
                Building software. <br />
                <span className="text-[#ededed]">Learning security.</span>{" "}
                <span className="text-[#cef042]">Exploring AI.</span>
              </span>
            </h1>

            {/* Supporting Description */}
            <p className="text-base sm:text-lg text-[#a1a1aa] leading-relaxed max-w-xl mb-7">
              {identity.shortIntro}
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 sm:gap-4 mb-8">
              <a
                href="#projects"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-sm bg-[#cef042] hover:bg-[#d9f852] text-[#101010] text-xs font-mono font-semibold transition-colors"
              >
                <span>View Projects</span>
                <ArrowDown className="w-3.5 h-3.5" />
              </a>

              <a
                href="#contact"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-sm bg-[#161616] hover:bg-[#202020] border border-[#2b2b2b] text-xs font-mono text-[#ededed] transition-colors"
              >
                <span>Get In Touch</span>
                <ArrowUpRight className="w-3.5 h-3.5 text-[#71717a]" />
              </a>
            </div>

            {/* Quick interest tags */}
            <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-[#71717a]">
              <span className="text-[#555555]">Focus:</span>
              <span className="px-2 py-0.5 rounded-xs bg-[#161616] border border-[#242424] text-[#a1a1aa]">
                Full-Stack Web
              </span>
              <span className="px-2 py-0.5 rounded-xs bg-[#161616] border border-[#242424] text-[#a1a1aa]">
                Application Security Basics
              </span>
              <span className="px-2 py-0.5 rounded-xs bg-[#161616] border border-[#242424] text-[#a1a1aa]">
                Applied AI
              </span>
            </div>
          </div>

          {/* Right Column: Profile Card with Real Photo */}
          <div className="lg:col-span-5 w-full">
            <div className="bg-[#141414] border border-[#242424] rounded-sm p-6 space-y-5 shadow-lg">
              {/* Profile Image & Name Header */}
              <div className="flex items-center gap-4 pb-5 border-b border-[#202020]">
                <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-full overflow-hidden border-2 border-[#cef042] bg-[#1a1a1a] shrink-0">
                  <img
                    src={identity.avatarUrl}
                    alt={identity.fullName}
                    className="w-full h-full object-cover object-top"
                  />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-[#ededed]">
                    {identity.fullName}
                  </h2>
                  <p className="text-xs text-[#cef042] font-mono">
                    CS Engineering Student
                  </p>
                  <p className="text-[11px] text-[#71717a] mt-0.5">
                    {identity.collegeName}
                  </p>
                </div>
              </div>

              {/* Verified Details */}
              <div className="space-y-2.5 text-xs text-[#a1a1aa]">
                <div className="flex items-center gap-2.5">
                  <GraduationCap className="w-4 h-4 text-[#cef042] shrink-0" />
                  <span>B.E. CSE (2024 - 2028)</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Award className="w-4 h-4 text-[#cef042] shrink-0" />
                  <span className="font-mono text-[#ededed]">CGPA: {identity.cgpa}</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <MapPin className="w-4 h-4 text-[#71717a] shrink-0" />
                  <span>{identity.location}</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Code className="w-4 h-4 text-[#71717a] shrink-0" />
                  <span>JavaScript • React • Node.js • Java</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Shield className="w-4 h-4 text-[#71717a] shrink-0" />
                  <span>Linux &amp; Web Security Basics</span>
                </div>
              </div>

              {/* Social / Direct Links */}
              <div className="pt-4 border-t border-[#202020] flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <a
                    href={contact.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-xs bg-[#181818] border border-[#262626] text-[#a1a1aa] hover:text-[#cef042] transition-colors"
                    aria-label="GitHub Profile"
                  >
                    <GithubIcon className="w-4 h-4" />
                  </a>
                  <a
                    href={contact.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-xs bg-[#181818] border border-[#262626] text-[#a1a1aa] hover:text-[#cef042] transition-colors"
                    aria-label="LinkedIn Profile"
                  >
                    <LinkedinIcon className="w-4 h-4" />
                  </a>
                </div>

                <a
                  href={`mailto:${contact.email}`}
                  className="text-xs font-mono text-[#cef042] hover:underline"
                >
                  {contact.email}
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
