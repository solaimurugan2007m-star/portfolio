"use client";

import React, { useState } from "react";
import { portfolioData } from "@/data/portfolio-data";
import { Mail, Copy, Check, Send, ArrowUpRight, CheckCircle2 } from "lucide-react";
import { GithubIcon, LinkedinIcon } from "@/components/BrandIcons";

export function Contact() {
  const { contact, identity } = portfolioData;
  const [copied, setCopied] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(contact.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) newErrors.name = "Please enter your name.";
    if (!formData.email.trim()) {
      newErrors.email = "Please enter your email address.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Please enter a valid email address.";
    }
    if (!formData.subject.trim()) newErrors.subject = "Please enter a subject.";
    if (!formData.message.trim()) newErrors.message = "Please write a message.";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    // Build mailto URL as client fallback
    const mailtoUrl = `mailto:${contact.email}?subject=${encodeURIComponent(
      `[Portfolio Inquiry] ${formData.subject}`
    )}&body=${encodeURIComponent(
      `From: ${formData.name} (${formData.email})\n\nMessage:\n${formData.message}`
    )}`;

    // Set submitted state for visual feedback
    setSubmitted(true);

    // Open mail client
    window.location.href = mailtoUrl;
  };

  return (
    <section id="contact" className="py-20 relative">
      <div className="max-w-5xl mx-auto px-5 sm:px-8">
        {/* Section Header */}
        <div className="mb-10">
          <span className="font-mono text-xs text-[#cef042] tracking-wider uppercase block mb-1">
            06 // Contact
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#ededed]">
            Get In Touch
          </h2>
          <p className="text-sm text-[#71717a] mt-1">
            Feel free to reach out for internship opportunities, project collaborations, or questions.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left Column: Direct Contact Info & Channels */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-[#141414] border border-[#242424] rounded-sm p-6 space-y-6">
              <div>
                <span className="font-mono text-xs uppercase tracking-wider text-[#71717a] block mb-2">
                  Direct Email
                </span>
                <div className="flex items-center justify-between gap-3 p-3 rounded-sm bg-[#101010] border border-[#202020]">
                  <span className="font-mono text-xs text-[#ededed] truncate">
                    {contact.email}
                  </span>
                  <button
                    onClick={handleCopyEmail}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xs bg-[#1a1a1a] hover:bg-[#222222] border border-[#2d2d2d] hover:border-[#cef042] text-[11px] font-mono text-[#ededed] transition-colors cursor-pointer shrink-0"
                    title="Copy Email to Clipboard"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-[#cef042]" />
                        <span className="text-[#cef042]">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-[#71717a]" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Social Channels */}
              <div className="space-y-3">
                <span className="font-mono text-xs uppercase tracking-wider text-[#71717a] block">
                  Connected Platforms
                </span>

                <a
                  href={contact.github}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-3 rounded-sm bg-[#101010] border border-[#202020] hover:border-[#383838] transition-colors group text-inherit no-underline"
                >
                  <div className="flex items-center gap-3">
                    <GithubIcon className="w-4 h-4 text-[#a1a1aa] group-hover:text-[#cef042] transition-colors" />
                    <div>
                      <div className="text-xs font-semibold text-[#ededed]">GitHub</div>
                      <div className="text-[11px] font-mono text-[#71717a]">
                        {contact.github.replace("https://", "")}
                      </div>
                    </div>
                  </div>
                  <ArrowUpRight className="w-3.5 h-3.5 text-[#71717a] group-hover:text-[#cef042] transition-colors" />
                </a>

                <a
                  href={contact.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-3 rounded-sm bg-[#101010] border border-[#202020] hover:border-[#383838] transition-colors group text-inherit no-underline"
                >
                  <div className="flex items-center gap-3">
                    <LinkedinIcon className="w-4 h-4 text-[#a1a1aa] group-hover:text-[#cef042] transition-colors" />
                    <div>
                      <div className="text-xs font-semibold text-[#ededed]">LinkedIn</div>
                      <div className="text-[11px] font-mono text-[#71717a]">
                        {contact.linkedin.replace("https://", "")}
                      </div>
                    </div>
                  </div>
                  <ArrowUpRight className="w-3.5 h-3.5 text-[#71717a] group-hover:text-[#cef042] transition-colors" />
                </a>
              </div>

              {/* Availability Note */}
              <div className="pt-4 border-t border-[#202020] text-xs text-[#71717a]">
                <span className="text-[#ededed] font-medium block mb-1">Response Time:</span>
                Typically responds within 24–48 hours for software engineering internships and academic inquiries.
              </div>
            </div>
          </div>

          {/* Right Column: Contact Message Form */}
          <div className="lg:col-span-7 bg-[#141414] border border-[#242424] rounded-sm p-6 sm:p-8">
            <div className="flex items-center justify-between pb-4 mb-6 border-b border-[#202020]">
              <h3 className="font-mono text-xs uppercase tracking-wider text-[#ededed] flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-[#cef042]" />
                Send a Message
              </h3>
              <span className="text-[11px] font-mono text-[#71717a]">
                Direct Mailto Fallback
              </span>
            </div>

            {submitted ? (
              <div className="py-12 text-center space-y-4">
                <div className="w-12 h-12 rounded-full bg-[#cef042]/10 border border-[#cef042]/30 text-[#cef042] flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h4 className="text-lg font-bold text-[#ededed]">
                  Message Prepared
                </h4>
                <p className="text-xs text-[#a1a1aa] max-w-sm mx-auto">
                  Your mail client has been opened with your message. If it didn&apos;t open automatically, you can also write directly to{" "}
                  <span className="text-[#cef042] font-mono">{contact.email}</span>.
                </p>
                <button
                  onClick={() => {
                    setSubmitted(false);
                    setFormData({ name: "", email: "", subject: "", message: "" });
                  }}
                  className="px-4 py-2 rounded-sm bg-[#1e1e1e] border border-[#2d2d2d] text-xs font-mono text-[#ededed] hover:border-[#cef042] transition-colors cursor-pointer"
                >
                  Send Another Message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 font-mono text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[#a1a1aa] text-[11px] uppercase tracking-wider mb-1.5">
                      Your Name <span className="text-[#cef042]">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g. Alex Chen"
                      className="w-full bg-[#101010] border border-[#262626] rounded-sm px-3 py-2.5 text-[#ededed] placeholder-[#555555] focus:outline-none focus:border-[#cef042] transition-colors"
                    />
                    {errors.name && (
                      <span className="text-[10px] text-[#ef4444] mt-1 block">{errors.name}</span>
                    )}
                  </div>

                  <div>
                    <label className="block text-[#a1a1aa] text-[11px] uppercase tracking-wider mb-1.5">
                      Your Email <span className="text-[#cef042]">*</span>
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="e.g. alex@example.com"
                      className="w-full bg-[#101010] border border-[#262626] rounded-sm px-3 py-2.5 text-[#ededed] placeholder-[#555555] focus:outline-none focus:border-[#cef042] transition-colors"
                    />
                    {errors.email && (
                      <span className="text-[10px] text-[#ef4444] mt-1 block">{errors.email}</span>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-[#a1a1aa] text-[11px] uppercase tracking-wider mb-1.5">
                    Subject <span className="text-[#cef042]">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    placeholder="e.g. Internship Inquiry / Project Discussion"
                    className="w-full bg-[#101010] border border-[#262626] rounded-sm px-3 py-2.5 text-[#ededed] placeholder-[#555555] focus:outline-none focus:border-[#cef042] transition-colors"
                  />
                  {errors.subject && (
                    <span className="text-[10px] text-[#ef4444] mt-1 block">{errors.subject}</span>
                  )}
                </div>

                <div>
                  <label className="block text-[#a1a1aa] text-[11px] uppercase tracking-wider mb-1.5">
                    Message <span className="text-[#cef042]">*</span>
                  </label>
                  <textarea
                    rows={5}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Write your note here..."
                    className="w-full bg-[#101010] border border-[#262626] rounded-sm px-3 py-2.5 text-[#ededed] placeholder-[#555555] focus:outline-none focus:border-[#cef042] transition-colors resize-none"
                  />
                  {errors.message && (
                    <span className="text-[10px] text-[#ef4444] mt-1 block">{errors.message}</span>
                  )}
                </div>

                <div className="pt-2 flex items-center justify-between">
                  <span className="text-[10px] text-[#71717a]">
                    * Required fields
                  </span>

                  <button
                    type="submit"
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-sm bg-[#cef042] hover:bg-[#d8f852] text-[#101010] text-xs font-mono font-semibold tracking-wide transition-all cursor-pointer focus:outline-none focus-visible:ring-1 focus-visible:ring-[#cef042]"
                  >
                    <span>Send Message</span>
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
