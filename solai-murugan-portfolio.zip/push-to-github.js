const fs = require('fs');
const path = require('path');
const git = require('isomorphic-git');
const http = require('isomorphic-git/http/node');

async function main() {
  const dir = 'C:/Users/Admin/.gemini/antigravity/scratch/solai-murugan-portfolio';
  
  const repoUrl = process.env.GITHUB_REPO_URL || process.argv[2];
  const token = process.env.GITHUB_TOKEN || process.argv[3];

  if (!repoUrl || !token) {
    console.error('Usage: node push-to-github.js <GITHUB_REPO_URL> <GITHUB_TOKEN>');
    console.error('Example: node push-to-github.js https://github.com/username/portfolio.git ghp_xxxx');
    process.exit(1);
  }

  console.log(`Pushing to ${repoUrl}...`);

  await git.push({
    fs,
    http,
    dir,
    remote: 'origin',
    ref: 'main',
    url: repoUrl,
    onAuth: () => ({ username: token, password: '' }),
  });

  console.log('Successfully pushed to GitHub!');
}

main().catch(err => {
  console.error('Push error:', err.message);
  process.exit(1);
});
