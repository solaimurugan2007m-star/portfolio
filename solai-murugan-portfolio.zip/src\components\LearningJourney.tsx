import React from "react";
import { portfolioData } from "@/data/portfolio-data";
import { GraduationCap, Award, Calendar, School } from "lucide-react";

export function LearningJourney() {
  const { educationJourney } = portfolioData;

  return (
    <section id="journey" className="py-20 border-b border-[#202020] relative">
      <div className="max-w-5xl mx-auto px-5 sm:px-8">
        {/* Section Header */}
        <div className="mb-10">
          <span className="font-mono text-xs text-[#cef042] tracking-wider uppercase block mb-1">
            05 // Education &amp; Timeline
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#ededed]">
            Learning Journey
          </h2>
          <p className="text-sm text-[#71717a] mt-1">
            My academic progression from secondary schooling to engineering degree.
          </p>
        </div>

        {/* Education Timeline */}
        <div className="relative border-l border-[#242424] ml-3 sm:ml-4 pl-6 sm:pl-8 space-y-10">
          {educationJourney.map((entry, index) => {
            const isLatest = index === 0;

            return (
              <div key={entry.degree} className="relative group">
                {/* Node dot */}
                <div
                  className={`absolute -left-[31px] sm:-left-[39px] top-1.5 w-3 h-3 rounded-full border-2 ${
                    isLatest
                      ? "bg-[#cef042] border-[#101010] ring-4 ring-[#cef042]/20"
                      : "bg-[#181818] border-[#383838]"
                  }`}
                />

                <div className="bg-[#141414] border border-[#222222] rounded-sm p-5 sm:p-6 space-y-3">
                  {/* Period & Score Header */}
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="flex items-center gap-1.5 font-mono text-xs text-[#cef042]">
                      <Calendar className="w-3.5 h-3.5" />
                      {entry.period}
                    </span>

                    {entry.score && (
                      <span className="inline-flex items-center gap-1 font-mono text-xs px-2 py-0.5 rounded-xs bg-[#cef042]/10 text-[#cef042] border border-[#cef042]/30 font-semibold">
                        <Award className="w-3.5 h-3.5" />
                        {entry.score}
                      </span>
                    )}
                  </div>

                  {/* Degree / Certificate Title */}
                  <h3 className="text-lg sm:text-xl font-bold text-[#ededed] flex items-center gap-2">
                    <GraduationCap className="w-5 h-5 text-[#cef042] shrink-0" />
                    <span>{entry.degree}</span>
                  </h3>

                  {/* Institution */}
                  <div className="flex items-center gap-2 text-xs font-mono text-[#a1a1aa]">
                    <School className="w-3.5 h-3.5 text-[#71717a] shrink-0" />
                    <span>{entry.institution}</span>
                  </div>

                  {/* Description */}
                  <p className="text-xs sm:text-sm text-[#71717a] leading-relaxed pt-1">
                    {entry.description}
                  </p>

                  {/* Highlights */}
                  <ul className="space-y-1 list-none p-0 m-0 text-xs text-[#a1a1aa] pt-2">
                    {entry.highlights.map((h, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-[#cef042] font-mono">›</span>
                        <span>{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
