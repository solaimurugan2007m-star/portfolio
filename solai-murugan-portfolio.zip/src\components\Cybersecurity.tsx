"use client";

import React from "react";
import { portfolioData } from "@/data/portfolio-data";
import { Shield, BookOpen, Terminal, Network } from "lucide-react";

export function Cybersecurity() {
  const { security } = portfolioData;

  const topicIcons = [Network, Terminal, Shield, BookOpen];

  return (
    <section id="security" className="py-20 border-b border-[#202020] relative">
      <div className="max-w-5xl mx-auto px-5 sm:px-8">
        {/* Section Header */}
        <div className="mb-10">
          <span className="font-mono text-xs text-[#cef042] tracking-wider uppercase block mb-1">
            04 // Security Learning
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#ededed]">
            {security.title}
          </h2>
          <p className="text-sm text-[#71717a] mt-1 max-w-2xl">
            {security.subtitle}
          </p>
        </div>

        {/* Honest Disclaimer */}
        <div className="mb-8 p-4 rounded-sm bg-[#141414] border border-[#262626] flex items-start gap-3">
          <Shield className="w-4 h-4 text-[#cef042] shrink-0 mt-0.5" />
          <p className="text-xs text-[#a1a1aa] leading-relaxed">
            {security.disclaimer}
          </p>
        </div>

        {/* 4 Core Learning Areas */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
          {security.topics.map((topic, index) => {
            const Icon = topicIcons[index % topicIcons.length];
            return (
              <div
                key={topic.title}
                className="p-5 rounded-sm bg-[#141414] border border-[#222222] space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Icon className="w-4 h-4 text-[#cef042]" />
                    <h3 className="text-sm font-semibold text-[#ededed]">
                      {topic.title}
                    </h3>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-xs bg-[#1a1a1a] text-[#71717a] border border-[#282828]">
                    {topic.status}
                  </span>
                </div>
                <p className="text-xs text-[#71717a] leading-relaxed">
                  {topic.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Tools Being Explored */}
        <div className="p-5 rounded-sm bg-[#141414] border border-[#222222]">
          <h3 className="font-mono text-xs font-semibold text-[#ededed] uppercase tracking-wider mb-3">
            Tools &amp; Environments I&apos;m Exploring:
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
            {security.toolsLearning.map((item) => (
              <div key={item.name} className="p-3 rounded-xs bg-[#101010] border border-[#1e1e1e]">
                <div className="text-xs font-mono font-semibold text-[#ededed] mb-1">
                  {item.name}
                </div>
                <div className="text-[11px] text-[#71717a] leading-tight">
                  {item.purpose}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
