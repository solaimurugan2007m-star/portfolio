"use client";

import React, { useState } from "react";
import { portfolioData, ProjectItem } from "@/data/portfolio-data";
import { Info, X } from "lucide-react";
import { GithubIcon } from "@/components/BrandIcons";

export function Projects() {
  const { projects } = portfolioData;
  const [notification, setNotification] = useState<string | null>(null);

  const handleRepoClick = (e: React.MouseEvent, project: ProjectItem) => {
    e.preventDefault();
    if (project.status === "In Progress") {
      setNotification(
        `"${project.name}" is currently under active local development. The GitHub repository will be published shortly.`
      );
    } else {
      setNotification(
        `"${project.name}" is in the planning phase. The code repository will be available once initial implementation begins.`
      );
    }
  };

  return (
    <section id="projects" className="py-20 border-b border-[#202020] relative">
      <div className="max-w-5xl mx-auto px-5 sm:px-8">
        {/* Section Header */}
        <div className="mb-10">
          <span className="font-mono text-xs text-[#cef042] tracking-wider uppercase block mb-1">
            03 // Projects
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#ededed]">
            Featured Projects
          </h2>
          <p className="text-sm text-[#71717a] mt-1">
            Practical applications I am actively developing and planning.
          </p>
        </div>

        {/* Status Notification */}
        {notification && (
          <div className="mb-6 p-3.5 rounded-sm bg-[#161616] border border-[#cef042]/40 text-xs font-mono flex items-center justify-between gap-3 text-[#ededed]">
            <div className="flex items-center gap-2">
              <Info className="w-4 h-4 text-[#cef042] shrink-0" />
              <span>{notification}</span>
            </div>
            <button
              onClick={() => setNotification(null)}
              className="text-[#71717a] hover:text-[#ededed]"
              aria-label="Dismiss"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Project Cards List */}
        <div className="space-y-6">
          {projects.map((project) => {
            const isInProgress = project.status === "In Progress";

            return (
              <div
                key={project.id}
                className="bg-[#141414] border border-[#222222] hover:border-[#303030] rounded-sm p-6 sm:p-7 transition-colors group"
              >
                {/* Header: Number, Status & Title */}
                <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
                  <div className="flex items-center gap-2.5">
                    <span className="font-mono text-xs font-semibold text-[#cef042] bg-[#cef042]/10 border border-[#cef042]/20 px-2 py-0.5 rounded-xs">
                      {project.number}
                    </span>
                    <h3 className="text-xl sm:text-2xl font-bold tracking-tight text-[#ededed]">
                      {project.name}
                    </h3>
                  </div>

                  <span
                    className={`text-xs font-mono px-2 py-0.5 rounded-xs border ${
                      isInProgress
                        ? "bg-[#38bdf8]/10 text-[#38bdf8] border-[#38bdf8]/30"
                        : "bg-[#202020] text-[#a1a1aa] border-[#2e2e2e]"
                    }`}
                  >
                    {project.status}
                  </span>
                </div>

                {/* Description */}
                <p className="text-sm text-[#a1a1aa] leading-relaxed mb-4">
                  {project.description}
                </p>

                {/* Key Features */}
                <ul className="space-y-1.5 list-none p-0 m-0 text-xs text-[#71717a] mb-5">
                  {project.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-[#cef042] font-mono">›</span>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                {/* Optional note (e.g. child safety note without medical claims) */}
                {project.note && (
                  <p className="text-[11px] text-[#71717a] italic mb-5 p-2 rounded-xs bg-[#101010] border border-[#1e1e1e]">
                    Note: {project.note}
                  </p>
                )}

                {/* Footer: Tech stack and action button (NO DEMO LINK) */}
                <div className="pt-4 border-t border-[#1f1f1f] flex flex-wrap items-center justify-between gap-4">
                  <div className="flex flex-wrap items-center gap-1.5">
                    {project.technologies.map((tech) => (
                      <span
                        key={tech}
                        className="px-2 py-0.5 rounded-xs bg-[#181818] border border-[#262626] text-xs font-mono text-[#a1a1aa]"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>

                  <div>
                    <button
                      onClick={(e) => handleRepoClick(e, project)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-sm bg-[#181818] hover:bg-[#202020] border border-[#282828] text-xs font-mono text-[#ededed] hover:border-[#cef042] transition-colors cursor-pointer"
                    >
                      <GithubIcon className="w-3.5 h-3.5 text-[#cef042]" />
                      <span>Code Repository</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
