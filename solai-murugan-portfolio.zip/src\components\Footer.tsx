"use client";

import React from "react";
import { portfolioData } from "@/data/portfolio-data";
import { ArrowUp, Mail } from "lucide-react";
import { GithubIcon, LinkedinIcon } from "@/components/BrandIcons";

export function Footer() {
  const { identity, contact } = portfolioData;

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="bg-[#0c0c0c] border-t border-[#202020] py-12 text-xs font-mono text-[#71717a]">
      <div className="max-w-5xl mx-auto px-5 sm:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b border-[#1b1b1b]">
          {/* Identity & Status */}
          <div className="flex flex-col items-center md:items-start text-center md:text-left gap-1">
            <span className="text-sm font-semibold tracking-tight text-[#ededed]">
              {identity.fullName}
            </span>
            <span className="text-[11px] text-[#71717a]">
              {identity.academicStatus} • {identity.location}
            </span>
          </div>

          {/* Social Links */}
          <div className="flex items-center gap-6">
            <a
              href={contact.github}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#a1a1aa] hover:text-[#cef042] transition-colors flex items-center gap-1.5"
            >
              <GithubIcon className="w-3.5 h-3.5" />
              <span>GitHub</span>
            </a>

            <a
              href={contact.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#a1a1aa] hover:text-[#cef042] transition-colors flex items-center gap-1.5"
            >
              <LinkedinIcon className="w-3.5 h-3.5" />
              <span>LinkedIn</span>
            </a>

            <a
              href={`mailto:${contact.email}`}
              className="text-[#a1a1aa] hover:text-[#cef042] transition-colors flex items-center gap-1.5"
            >
              <Mail className="w-3.5 h-3.5" />
              <span>Email</span>
            </a>
          </div>

          {/* Back to top */}
          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-sm bg-[#141414] hover:bg-[#1a1a1a] border border-[#242424] hover:border-[#383838] text-[11px] text-[#a1a1aa] hover:text-[#ededed] transition-colors cursor-pointer"
            aria-label="Back to top of page"
          >
            <span>Top</span>
            <ArrowUp className="w-3 h-3 text-[#cef042]" />
          </button>
        </div>

        {/* Bottom Credits & Copyright */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left text-[11px]">
          <div>
            &copy; 2026 {identity.fullName}. All rights reserved.
          </div>
          <div className="text-[#555555]">
            Built with care &amp; clean engineering
          </div>
        </div>
      </div>
    </footer>
  );
}
