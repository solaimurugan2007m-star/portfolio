export type SkillLevel = "Practiced" | "Familiar" | "Learning";

export interface SkillItem {
  name: string;
  level: SkillLevel;
}

export interface SkillCategory {
  title: string;
  skills: SkillItem[];
}

export interface ProjectItem {
  id: string;
  number: string;
  name: string;
  description: string;
  status: "In Progress" | "Planned";
  technologies: string[];
  features: string[];
  note?: string;
  githubUrl?: string;
}

export interface EducationEntry {
  degree: string;
  institution: string;
  period: string;
  score?: string;
  description: string;
  highlights: string[];
}

export interface SecurityTopic {
  title: string;
  description: string;
  status: "Learning" | "Familiar";
}

export interface PortfolioData {
  identity: {
    fullName: string;
    monogram: string;
    headline: string;
    shortIntro: string;
    academicStatus: string;
    collegeName: string;
    cgpa: string;
    location: string;
    avatarUrl: string;
    isOpenToOpportunities: boolean;
    availabilityText: string;
    bio: string[];
  };
  contact: {
    email: string;
    github: string;
    linkedin: string;
  };
  skills: SkillCategory[];
  projects: ProjectItem[];
  security: {
    title: string;
    subtitle: string;
    disclaimer: string;
    topics: SecurityTopic[];
    toolsLearning: { name: string; purpose: string }[];
  };
  educationJourney: EducationEntry[];
}

export const portfolioData: PortfolioData = {
  identity: {
    fullName: "Solai Murugan M",
    monogram: "sm",
    headline: "Software Developer | Security Learner | AI Builder",
    shortIntro:
      "I'm a Computer Science student at PSNA College of Engineering and Technology interested in building useful software, exploring application security, and understanding how technology works beneath the surface.",
    academicStatus: "B.E. Computer Science and Engineering (2024 - 2028)",
    collegeName: "PSNA College of Engineering and Technology, Dindigul",
    cgpa: "8.01",
    location: "Dindigul, Tamil Nadu, India",
    avatarUrl: "/profile.png",
    isOpenToOpportunities: true,
    availabilityText: "Open to internships & junior developer roles",
    bio: [
      "I am a Computer Science and Engineering student at PSNA College of Engineering and Technology, Dindigul (CGPA: 8.01). I enjoy writing clean code, building responsive full-stack web applications, and solving real-world problems.",
      "Alongside software engineering, I have recently started learning application security, networking fundamentals, and Linux system administration. Understanding how systems function under the surface helps me build more secure and resilient applications.",
      "I believe in learning by building projects, experimenting with AI tools, and continuously practicing in student security labs.",
    ],
  },
  contact: {
    email: "solaimurugan2007.m@gmail.com",
    github: "https://github.com/solaimurugan-m",
    linkedin: "https://linkedin.com/in/solai-murugan-m",
  },
  skills: [
    {
      title: "Programming",
      skills: [
        { name: "Java", level: "Practiced" },
        { name: "JavaScript", level: "Practiced" },
        { name: "Python", level: "Practiced" },
      ],
    },
    {
      title: "Frontend",
      skills: [
        { name: "HTML & CSS", level: "Practiced" },
        { name: "React.js", level: "Practiced" },
        { name: "Next.js", level: "Familiar" },
      ],
    },
    {
      title: "Backend & Database",
      skills: [
        { name: "Node.js", level: "Practiced" },
        { name: "Express.js", level: "Practiced" },
        { name: "REST APIs", level: "Practiced" },
        { name: "SQL", level: "Practiced" },
        { name: "MongoDB", level: "Practiced" },
      ],
    },
    {
      title: "Cybersecurity (Starting Out)",
      skills: [
        { name: "Linux Basics", level: "Practiced" },
        { name: "Networking Fundamentals", level: "Familiar" },
        { name: "OWASP Top 10 Concepts", level: "Learning" },
        { name: "Nmap Basics", level: "Learning" },
        { name: "Wireshark Basics", level: "Learning" },
        { name: "Burp Suite (Exploring)", level: "Learning" },
      ],
    },
    {
      title: "AI & Tools",
      skills: [
        { name: "LLM APIs", level: "Familiar" },
        { name: "Prompt Engineering", level: "Practiced" },
        { name: "Git & GitHub", level: "Practiced" },
        { name: "VS Code", level: "Practiced" },
        { name: "Postman", level: "Practiced" },
      ],
    },
  ],
  projects: [
    {
      id: "ai-customer-support",
      number: "01",
      name: "AI Customer Support Platform",
      description:
        "A web application that uses AI to answer customer questions from a knowledge base and helps manage support requests with structured routing.",
      status: "In Progress",
      technologies: ["React", "Node.js", "Express", "MongoDB", "SQL", "LLM API"],
      features: [
        "Answers frequently asked questions using knowledge base documents",
        "Automated responses powered by LLM completion endpoints",
        "Ticket escalation flow for complex inquiries",
        "Staff dashboard to manage and update support requests",
      ],
      githubUrl: "https://github.com/solaimurugan-m/ai-customer-support-platform",
    },
    {
      id: "ai-learning-platform-kids",
      number: "02",
      name: "AI Learning Platform for Children",
      description:
        "An accessible, personalized learning platform designed to support children with different learning needs, including ADHD and learning difficulties.",
      status: "Planned",
      technologies: ["React", "Node.js", "MongoDB", "SQL", "LLM API"],
      features: [
        "Bite-sized micro-lessons designed to avoid cognitive overload",
        "Clear, readable visual layout with dyslexia-friendly text options",
        "Interactive comprehension checks with positive encouragement",
        "Parent and teacher dashboard to review lessons and monitor progress",
      ],
      note: "Focused on accessibility and child safety with parental oversight. Purely an educational tool; does not provide medical diagnosis or treatment.",
      githubUrl: "https://github.com/solaimurugan-m/accessible-learning-platform",
    },
    {
      id: "developer-project-assignment",
      number: "03",
      name: "Developer Project Assignment Platform",
      description:
        "A platform for assigning development projects, managing tasks, tracking deadlines and monitoring team progress.",
      status: "Planned",
      technologies: ["React", "Node.js", "Express", "SQL", "MongoDB"],
      features: [
        "Assign and track development projects across team members",
        "Simple task boards with status updates (To Do, In Progress, Done)",
        "Deadline reminders and project progress overview",
        "Basic user role management (Project Lead and Contributor)",
      ],
      githubUrl: "https://github.com/solaimurugan-m/project-assignment-platform",
    },
  ],
  security: {
    title: "Learning Application Security",
    subtitle:
      "Understanding how web applications work under the hood and learning fundamental security principles to build more reliable software.",
    disclaimer:
      "I am at the beginning of my security journey. All my learning and lab exercises are practiced strictly on authorized, sandboxed platforms like TryHackMe and PortSwigger Web Security Academy.",
    topics: [
      {
        title: "Networking Basics",
        description: "Understanding TCP/IP, DNS lookups, ports, and how HTTP and HTTPS requests travel.",
        status: "Familiar",
      },
      {
        title: "Linux Command Line",
        description: "Navigating Linux systems, understanding file permissions, and writing basic shell scripts.",
        status: "Familiar",
      },
      {
        title: "Web Security Fundamentals",
        description: "Learning how common vulnerabilities work (such as SQL injection and broken access controls).",
        status: "Learning",
      },
      {
        title: "Defensive Coding",
        description: "Writing code that validates inputs, uses parameterized queries, and avoids common security pitfalls.",
        status: "Learning",
      },
    ],
    toolsLearning: [
      { name: "Linux CLI", purpose: "Daily operating system practice and server administration basics" },
      { name: "Nmap", purpose: "Learning network port discovery and service detection in local labs" },
      { name: "Wireshark", purpose: "Inspecting packet headers and observing protocol handshakes" },
      { name: "Burp Suite", purpose: "Getting started with HTTP request inspection and web proxies" },
    ],
  },
  educationJourney: [
    {
      degree: "B.E. Computer Science and Engineering",
      institution: "PSNA College of Engineering and Technology, Dindigul",
      period: "2024 - 2028",
      score: "CGPA: 8.01",
      description:
        "Currently pursuing bachelor's degree in Computer Science and Engineering. Focusing on core software engineering, data structures, full-stack web technologies, and application security.",
      highlights: [
        "Maintaining a consistent academic record with 8.01 CGPA",
        "Hands-on coursework: Data Structures, OOP (Java), Database Management, Operating Systems",
        "Active self-learning in modern web development (React, Node.js) and cybersecurity fundamentals",
      ],
    },
    {
      degree: "Higher Secondary Certificate (HSC)",
      institution: "Shri Maharishi Vidya Mandir, Dindigul",
      period: "Completed 2024",
      description:
        "Completed higher secondary education with major focus on Mathematics, Physics, Chemistry, and Computer Science.",
      highlights: [
        "Strong foundation in mathematics and analytical problem solving",
        "Early exposure to computer programming and basic algorithmic logic",
      ],
    },
    {
      degree: "Secondary School Leaving Certificate (SSLC)",
      institution: "Shri Maharishi Vidya Mandir, Dindigul",
      period: "Completed 2022",
      description:
        "Completed secondary school education with distinction in general sciences and mathematics.",
      highlights: [
        "Built early interest in technology, computers, and science fundamentals",
        "Active participation in school academic and co-curricular activities",
      ],
    },
  ],
};
